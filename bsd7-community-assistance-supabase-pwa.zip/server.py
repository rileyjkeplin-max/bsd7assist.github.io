import argparse
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path(__file__).resolve().parent


class StaticAppHandler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        route = unquote(urlparse(path).path).lstrip("/")
        if not route:
            route = "index.html"
        target = (ROOT / route).resolve()
        try:
            target.relative_to(ROOT)
        except ValueError:
            return str(ROOT / "index.html")
        if target.is_dir():
            target = target / "index.html"
        return str(target)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        super().end_headers()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--demo", action="store_true", help="Accepted for compatibility with older instructions.")
    args = parser.parse_args()
    print(f"BSD #7 Community Assistance preview: http://localhost:{args.port}")
    ThreadingHTTPServer(("0.0.0.0", args.port), StaticAppHandler).serve_forever()


if __name__ == "__main__":
    main()
